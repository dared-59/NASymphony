document.addEventListener("DOMContentLoaded", function() {
    var input = document.querySelector("#phone");
    window.intlTelInput(input, {
        separateDialCode: true,
        initialCountry: "in",
        geoIpLookup: function(success, failure) {
            fetch('https://ipinfo.io?token=YOUR_API_TOKEN') // You can use a service like ipinfo.io
                .then(function(response) { return response.json(); })
                .then(function(data) {
                    success(data.country);
                })
                .catch(function() {
                    success("us");
                });
        },
        utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js"
    });
});

document.getElementById('registrationForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;

    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[\W_]).{8,}$/;

    if (!passwordRegex.test(password)) {
        alert('Password must contain at least one lowercase letter, one uppercase letter, one special character, and be at least 8 characters long.');
        return;
    }

    if (password !== confirmPassword) {
        alert('Passwords do not match. Please try again.');
        return;
    }

    const userId = 'USER' + Math.floor(Math.random() * 10000);
    document.getElementById('generatedUserId').innerText = userId;

    const ackModal = new bootstrap.Modal(document.getElementById('ackModal'));
    ackModal.show();

    this.reset();
});

