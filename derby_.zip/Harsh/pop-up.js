document.addEventListener('DOMContentLoaded', function() {
    // Simulate showing the pop-up after checkout
    const showThankYouModal = true; // Set to true after successful checkout
    if (showThankYouModal) {
        const thankYouModal = new bootstrap.Modal(document.getElementById('thankYouModal'));
        thankYouModal.show();
    }
});
