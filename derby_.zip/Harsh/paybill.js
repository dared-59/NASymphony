document.addEventListener('DOMContentLoaded', function() {
    const username = "John Doe"; // Replace with dynamic username
    document.getElementById('username').textContent = username;

    document.getElementById('logoutBtn').addEventListener('click', function() {
        // Perform logout action (e.g., redirect to login page)
        window.location.href = 'login.html';
    });

    document.getElementById('paymentForm').addEventListener('submit', function(e) {
        e.preventDefault();
        // Show credit card details modal
        const creditCardModal = new bootstrap.Modal(document.getElementById('creditCardModal'));
        creditCardModal.show();
    });

    document.getElementById('creditCardForm').addEventListener('submit', function(e) {
        e.preventDefault();
        // Generate a random transaction ID
        const transactionId = 'TXN' + Math.floor(Math.random() * 1000000);
        alert('Payment Successful!\nTransaction ID: ' + transactionId);

        // Redirect to invoice page or display invoice details
        window.location.href = 'invoice.html'; // Replace with your invoice page
    });

    document.getElementById('backToHomeBtn').addEventListener('click', function() {
        // Redirect to home page
        window.location.href = 'home.html';
    });
});
