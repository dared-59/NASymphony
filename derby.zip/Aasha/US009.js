function generateInvoice() {
    var userId = document.getElementById('userId').value;
    if(userId.trim() === '') {
        alert('Please enter a valid UserID.');
        return;
    }

    var invoiceData = {
        reservationId: '12345',
        userDetails: 'John',
        roomCharges: '2000/-',
        additionalServicesCharges: '250/-'
    };

    document.getElementById('reservationId').innerText = invoiceData.reservationId;
    document.getElementById('userDetails').innerText = invoiceData.userDetails;
    document.getElementById('roomCharges').innerText = invoiceData.roomCharges;
    document.getElementById('serviceCharges').innerText = invoiceData.additionalServicesCharges;

    document.getElementById('invoiceDetails').style.display = 'block';
}

function finalizeInvoice() {
    alert('Invoice has been finalized and generated.');
    // Add logic to finalize and generate the invoice
}